const Events = require("../models/event.schema");
const { sendingDataInHeader } = require("../services/sendingDataInHeader");
const { apiResponse } = require("../utils/apiResponse");
const { uploadImageInCloudinary } = require("./cloudnary.config");
const cloudinary = require('cloudinary').v2

async function createEvents(req, res) {

    const userData = await sendingDataInHeader(req);

    if (!userData) return apiResponse(res, 401, "Unauthorised request");

    console.log(userData?.id)

    const { title, description, date, startTime, endTime, location, overView, goodToKnow, eventTickets } = req.body;
    const image = req.files;

    console.log(image?.buffer)

    let url = null;
    let public_id = null;

    if (image) { 
         
        const results = [];

        for (const file of req.files) {
            const uploadResult = await new Promise((resolve, reject) => {
                cloudinary.uploader.upload_stream(
                    { folder: 'uploads' },
                    (error, result) => {
                        if (error) return reject(error);
                        resolve(result);
                    }
                ).end(file.buffer);
            });
            results.push(uploadResult.secure_url);
        }
    }


    if (!title || !description || !date || !location) {
        return apiResponse(res, 400, "All fields are required", null)
    }

    await Events.create({
        title,
        description,
        url,
        date,
        public_id,
        startTime,
        endTime,
        location,
        overView,
        goodToKnow,
        organizer: userData?.id,
        eventTickets
    })

    return apiResponse(res, 200, "success", { title })
}

module.exports = { createEvents }